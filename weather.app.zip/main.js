document.getElementById('submit').addEventListener('click', function() {
    const city = document.getElementById('city-input').value;
    if (city) {
        fetchWeatherData(city);
    } else {
        alert('Please enter a city name.');
    }
});

function fetchWeatherData(city) {
    const apiKey = 'b97d4acd46864ef0ab9ab3118c324852';
    const url = `https://api.weatherbit.io/v2.0/current?city=${encodeURIComponent(city)}&key=${apiKey}`;

    fetch(url)
        .then(response => response.json())
        .then(data => displayWeather(data))
        .catch(error => console.error('Error fetching weather data:', error));
}

function displayWeather(data) {
    // Weatherbit returns an array of results in data.data
    if (data && data.data && data.data.length > 0) {
        const cityName = data.data[0].city_name;
        const temp = data.data[0].temp;
        const weatherDescription = data.data[0].weather.description;

        document.getElementById('city-name').innerText = cityName;
        document.getElementById('temperature').innerText = `Temperature: ${temp}°C`;
        document.getElementById('weather-description').innerText = `Weather: ${weatherDescription.charAt(0).toUpperCase() + weatherDescription.slice(1)}`;
    } else {
        alert('City not found. Please try again.');
    }
}